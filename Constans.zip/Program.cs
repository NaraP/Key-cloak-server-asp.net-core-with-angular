﻿using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
    public class MyFirstClass
    {
        public string Option1 { get; set; }
        public int Option2 { get; set; }
    }

    public class MySecondClass
    {
        public string SettingOne { get; set; }
        public int SettingTwo { get; set; }
    }

    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 
    public class Aps
    {
        public string type { get; set; }
    }

    public class Parameters
    {
        public DateTime startDate { get; set; }
        public DateTime endDate { get; set; }
    }

    public class CloudeBlue
    {
        public CloudeBlue()
        {
            aps = new Aps();
            parameters = new Parameters();
        }
        public Aps aps { get; set; }
        public string commonName { get; set; }
        public Parameters parameters { get; set; }
        public string format { get; set; }
        public bool notifyByEmail { get; set; }
        public string eventType { get; set; }
    }




    class Program
    {
        public static async Task Main(string[] args)
        {
            CloudeBlue cloudeBlue = new CloudeBlue();
            cloudeBlue.aps.type = "http://www.odin.com/rde/report-template/1.1";// Read from app.config file
            cloudeBlue.commonName = Constans.commonName;
            cloudeBlue.format = Constans.format;
            cloudeBlue.notifyByEmail = false;
            cloudeBlue.eventType = Constans.eventType;
            cloudeBlue.parameters.startDate = Convert.ToDateTime("2018-09-09T00:00:00Z");
            cloudeBlue.parameters.endDate = Convert.ToDateTime("2018-10-05T23:59:59Z");

            var json = Newtonsoft.Json.JsonConvert.SerializeObject(cloudeBlue);

            CloudBlueSecondOne cloudBlueSecondOne  = JsonConvert.DeserializeObject<CloudBlueSecondOne>(File.ReadAllText(@"C:\Users\DevTemp\source\repos\SampleProjects\ConsoleApp\json1.json"));

            var cloudblueUrl = cloudBlueSecondOne.reportFiles.aps.href;

            //Dependency injection
            var services = new ServiceCollection();
            ConfigureServices(services);

            // create service provider
            var serviceProvider = services.BuildServiceProvider();

            // entry to run app
                  serviceProvider.GetService<WeatherClientConfig>();

            var builder = new ConfigurationBuilder()
               .SetBasePath(AppDomain.CurrentDomain.BaseDirectory)
               .AddJsonFile("appsettings.json");

            IConfiguration config = builder.Build();

            var section = config.GetSection(nameof(WeatherClientConfig));
            var article = config.GetSection("articles").Get<Articles>();

            var weatherClientConfig = section.Get<WeatherClientConfig>();

            var myFirstClass = config.GetSection("MyFirstClass").Get<MyFirstClass>();
            var mySecondClass = config.GetSection("MySecondClass").Get<MySecondClass>();

            Console.WriteLine(weatherClientConfig.WeatherAPIUrl);
            Console.WriteLine(weatherClientConfig.IsEnabled);
            Console.WriteLine(weatherClientConfig.Timeout);
        }

        private static void ConfigureServices(ServiceCollection services)
        {
            IConfigurationRoot configurationRoot = Helper.GetConfigurationSettings();

            // Add access to generic IConfigurationRoot
            services.AddSingleton<IConfigurationRoot>(configurationRoot);

            var myFirstClass = configurationRoot.GetSection("MyFirstClass").Get<MyFirstClass>();
            var mySecondClass = configurationRoot.GetSection("MySecondClass").Get<MySecondClass>();

            // add services:
            // services.AddTransient<IMyRespository, MyConcreteRepository>();

            // add app
            services.AddTransient<WeatherClientConfig>();
        }
    }

    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 

    [JsonObject("application")]
    public class Application
    {
        [JsonProperty("name")]
        public string Name { get; set; }
    }
    public class Articles
    {
        public string title { get; set; }
        public string thumbnailLink { get; set; }
        public string authorProfileLink { get; set; }
        public string authorName { get; set; }
        public string publishDate { get; set; }
        public string text { get; set; }
        public string link { get; set; }
    }

    public class Root
    {
        public Articles articles { get; set; }
    }



    public class WeatherClientConfig
    {
        public bool IsEnabled { get; set; }
        public string WeatherAPIUrl { get; set; }
        public string Timeout { get; set; }
    }
}
