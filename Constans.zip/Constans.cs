﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp
{
   public static class Constans
    {
        public const string commonName = "NW Finance";
        public const string format = "JSON";
        public const string eventType = "ONETIME";
        public const string notifyByEmail = "false";
    }

    // Root myDeserializedClass = JsonConvert.DeserializeObject<Root>(myJsonResponse); 


    public class ApsData
    {
        public string link { get; set; }
        public string href { get; set; }
    }
 

    public class ReportFiles
    {
        public ApsData aps { get; set; }
    }


    public class CloudBlueSecondOne
    {
        public CloudBlueSecondOne()
        {
            aps = new ApsData();
            reportFiles = new ReportFiles();
        }
        public ApsData aps { get; set; }
        public ReportFiles reportFiles { get; set; }
    }


}
